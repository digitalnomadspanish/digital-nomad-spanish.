DIGITAL NOMAD SPANISH - DEPLOYMENT

This folder is a static website. The homepage file is index.html.

GITHUB
1. Open the repository for this website.
2. Upload index.html to the repository ROOT (same level as this README; not inside another folder).
3. Commit the changes to the main branch.

RENDER
1. Create or open a Static Site connected to this GitHub repository.
2. Branch: main
3. Root Directory: leave blank (unless the website is intentionally inside a subfolder; if so use that folder).
4. Build Command: leave blank.
5. Publish Directory: .
6. Save and deploy the latest commit.

IMPORTANT
- Do not deploy the GitHub repository page URL as the website address. Use the Render URL ending in onrender.com, or connect the custom domain in Render.
- If using a custom domain, follow Render's domain/DNS instructions and wait for verification and HTTPS provisioning.
- The contact form currently opens the visitor's email app as a fallback. It does not submit to a server-side form service because FORM_ENDPOINT is blank.
- The privacy policy contains placeholder company/address/tax-ID fields. Replace these with the correct legal details before publishing the privacy policy.
